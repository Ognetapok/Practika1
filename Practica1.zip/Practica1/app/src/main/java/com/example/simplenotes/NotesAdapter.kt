package com.example.simplenotes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

// ListAdapter - умный адаптер, который сам определяет изменения в списке
class NotesAdapter(
    // Лямбда-функция, которая будет вызвана при клике на кнопку удаления
    private val onDeleteClick: (Note) -> Unit
) : ListAdapter<Note, NotesAdapter.NoteViewHolder>(NoteDiffCallback) {

    // Создает новые ViewHolder'ы когда RecyclerView это требует
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        // Надуваем (inflate) наш макет item_note.xml
        val itemView = layoutInflater.inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(itemView)
    }

    // Связывает данные (заметку) с ViewHolder'ом
    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        // getItem(position) - метод ListAdapter, который возвращает элемент по позиции
        val currentNote = getItem(position)
        holder.bind(currentNote)
    }

    // Внутренний класс ViewHolder. Хранит ссылки на View в элементе списка
    inner class NoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        private val tvContent: TextView = itemView.findViewById(R.id.tvContent)
        private val btnDelete: Button = itemView.findViewById(R.id.btnDelete)

        fun bind(note: Note) {
            // Устанавливаем данные в View
            tvTitle.text = note.title
            tvContent.text = note.content

            // Вешаем обработчик на кнопку удаления
            btnDelete.setOnClickListener {
                onDeleteClick(note) // Вызываем переданную извне лямбду, передавая в нее текущую заметку
            }
        }
    }

    // Companion object для DiffUtil
    companion object {
        // DiffUtil сравнивает два списка и определяет, что изменилось
        // Это нужно для анимированного и эффективного обновления списка
        private val NoteDiffCallback = object : DiffUtil.ItemCallback<Note>() {
            // Проверяет, один и тот же ли это объект (например, по id)
            override fun areItemsTheSame(oldItem: Note, newItem: Note): Boolean {
                return oldItem.id == newItem.id
            }

            // Проверяет, одинаково ли содержимое объектов
            override fun areContentsTheSame(oldItem: Note, newItem: Note): Boolean {
                return oldItem == newItem
            }
        }
    }
}