package com.example.simplenotes

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.simplenotes.databinding.ActivityMainBinding
import com.example.simplenotes.databinding.DialogAddNoteBinding
import kotlinx.coroutines.launch
class MainActivity : AppCompatActivity() {

    // ViewBinding для доступа к элементам макета
    private lateinit var binding: ActivityMainBinding

    // Ленивая инициализация базы данных (создается при первом обращении)
    private val database by lazy { NoteDatabase.getDatabase(this) }

    // Адаптер для RecyclerView с лямбдой для удаления заметок
    private val notesAdapter = NotesAdapter(
        onDeleteClick = { note -> deleteNote(note) }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Настройка ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Настройка RecyclerView
        setupRecyclerView()

        // Подписка на обновления из базы данных
        observeNotes()

        // Обработчик клика на кнопку добавления
        binding.fabAdd.setOnClickListener {
            showAddNoteDialog()
        }
    }

    // Настройка RecyclerView
    private fun setupRecyclerView() {
        binding.recyclerView.apply {
            adapter = notesAdapter  // Устанавливаем адаптер
            layoutManager = LinearLayoutManager(this@MainActivity)  // LinearLayout для вертикального списка
        }
    }

    // Подписка на обновления из базы данных
    private fun observeNotes() {
        lifecycleScope.launch {
            // "Собираем" Flow из базы данных
            database.noteDao().getAllNotes().collect { notesList ->
                // Этот код выполняется КАЖДЫЙ РАЗ при изменении данных в БД
                notesAdapter.submitList(notesList)  // Обновляем данные в адаптере
            }
        }
    }

    // Показывает диалог для добавления новой заметки
    private fun showAddNoteDialog() {
        // Создаем binding для диалога
        val dialogBinding = DialogAddNoteBinding.inflate(layoutInflater)

        // Создаем и показываем диалог
        AlertDialog.Builder(this)
            .setTitle("Новая заметка")
            .setView(dialogBinding.root)
            .setPositiveButton("Добавить") { _, _ ->
                // Получаем текст из полей ввода
                val title = dialogBinding.etTitle.text.toString()
                val content = dialogBinding.etContent.text.toString()

                // Проверяем, что заголовок не пустой
                if (title.isNotEmpty()) {
                    // Создаем новую заметку
                    val newNote = Note(
                        title = title,
                        content = content,
                        timestamp = System.currentTimeMillis()  // Текущее время для сортировки
                    )
                    // Вставляем заметку в базу данных
                    insertNote(newNote)
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // Вставка заметки в базу данных
    private fun insertNote(note: Note) {
        lifecycleScope.launch {
            // Запускаем в корутине, чтобы не блокировать UI поток
            database.noteDao().insert(note)
            // Адаптер автоматически обновится благодаря Flow!
        }
    }

    // Удаление заметки из базы данных
    private fun deleteNote(note: Note) {
        lifecycleScope.launch {
            database.noteDao().delete(note)
            // Адаптер автоматически обновится благодаря Flow!
        }
    }
}